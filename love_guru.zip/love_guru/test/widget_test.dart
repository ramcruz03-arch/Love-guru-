import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:love_guru/screens/connect_tab.dart';
import 'package:love_guru/screens/home_tab.dart';

void main() {
  testWidgets('Home tab shows greeting and daily question', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: HomeTab())),
    );

    expect(find.text('Grow closer, one conversation at a time.'), findsOneWidget);
    expect(find.text('Daily Question'), findsOneWidget);
    expect(find.text('Your answer'), findsOneWidget);
  });

  testWidgets('Connect tab lists the four topics', (tester) async {
    await tester.pumpWidget(
      const MaterialApp(home: Scaffold(body: ConnectTab())),
    );

    expect(find.text('Guided Conversations'), findsOneWidget);
    for (final title in ['Appreciation', 'Future Plans', 'Boundaries', 'Intimacy']) {
      expect(find.text(title), findsOneWidget);
    }
  });
}
