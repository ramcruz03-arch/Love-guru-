#!/usr/bin/env bash
# Generates the android/ platform folder with YOUR installed Flutter version.
# Safe to run more than once: existing files (lib/, pubspec.yaml, etc.) are never overwritten.
set -euo pipefail
cd "$(dirname "$0")/.."

if [ ! -d android ]; then
  flutter create . --platforms android --org com.loveguru --project-name love_guru
fi

MANIFEST="android/app/src/main/AndroidManifest.xml"
if [ -f "$MANIFEST" ]; then
  sed -i.bak 's/android:label="love_guru"/android:label="Love Guru"/' "$MANIFEST"
  rm -f "$MANIFEST.bak"
fi

echo "Android platform files are ready."
