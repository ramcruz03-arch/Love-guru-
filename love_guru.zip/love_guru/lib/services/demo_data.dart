import 'package:flutter/material.dart';

import '../models/conversation_topic.dart';

/// Static demo content. Replace with real AI-generated content later.
class DemoData {
  DemoData._();

  static const String dailyQuestion =
      'What’s one small thing I did this week that made you feel loved?';

  static const int connectionStreakDays = 1;

  static const String repairMessage =
      'I felt hurt when this happened. I want us to understand each other '
      'and find a calmer way forward.';

  static const List<ConversationTopic> topics = [
    ConversationTopic(
      title: 'Appreciation',
      description: 'Notice and name what you value in each other.',
      starterQuestion:
          'What’s something about me you’ve come to appreciate more over time?',
      icon: Icons.favorite_border,
    ),
    ConversationTopic(
      title: 'Future Plans',
      description: 'Dream a little and plan the road ahead together.',
      starterQuestion:
          'Where do you picture us a year from now, and what would make that year feel good for both of us?',
      icon: Icons.explore_outlined,
    ),
    ConversationTopic(
      title: 'Boundaries',
      description: 'Talk kindly about space, needs, and respect.',
      starterQuestion:
          'Is there something you need more space or support with right now, and how can I respect that?',
      icon: Icons.shield_outlined,
    ),
    ConversationTopic(
      title: 'Intimacy',
      description: 'Explore closeness, affection, and feeling seen.',
      starterQuestion:
          'When do you feel closest to me, and how can we make more room for those moments?',
      icon: Icons.volunteer_activism_outlined,
    ),
  ];
}
