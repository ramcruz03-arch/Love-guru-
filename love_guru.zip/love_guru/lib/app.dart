import 'package:flutter/material.dart';

import 'screens/splash_screen.dart';

/// Brand colours for Love Guru.
class AppColors {
  AppColors._();

  /// Soft coral - the primary brand colour.
  static const Color coral = Color(0xFFE97451);

  /// Darker coral used for text and icons on light backgrounds (good contrast).
  static const Color coralDeep = Color(0xFFB4492A);

  /// Dark brown used for text placed on top of coral (good contrast).
  static const Color onCoral = Color(0xFF2B1510);

  /// Warm off-white app background.
  static const Color background = Color(0xFFFFF7F3);

  /// Pale blush used for soft fills and borders.
  static const Color blush = Color(0xFFFCE3D9);

  /// Main text colour.
  static const Color ink = Color(0xFF3A2A25);

  /// Secondary text colour.
  static const Color inkSoft = Color(0xFF6B5750);
}

class LoveGuruApp extends StatelessWidget {
  const LoveGuruApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Love Guru',
      debugShowCheckedModeBanner: false,
      theme: _buildTheme(),
      home: const SplashScreen(),
    );
  }

  ThemeData _buildTheme() {
    final colorScheme = ColorScheme.fromSeed(
      seedColor: AppColors.coral,
      primary: AppColors.coral,
      onPrimary: AppColors.onCoral,
      surface: AppColors.background,
      onSurface: AppColors.ink,
    );

    final radius = BorderRadius.circular(16);

    return ThemeData(
      useMaterial3: true,
      colorScheme: colorScheme,
      scaffoldBackgroundColor: AppColors.background,
      appBarTheme: const AppBarTheme(
        backgroundColor: AppColors.background,
        foregroundColor: AppColors.ink,
        elevation: 0,
        centerTitle: false,
      ),
      cardTheme: CardThemeData(
        color: Colors.white,
        elevation: 0,
        margin: EdgeInsets.zero,
        shape: RoundedRectangleBorder(
          borderRadius: radius,
          side: const BorderSide(color: AppColors.blush),
        ),
      ),
      inputDecorationTheme: InputDecorationTheme(
        filled: true,
        fillColor: Colors.white,
        labelStyle: const TextStyle(color: AppColors.inkSoft),
        floatingLabelStyle: const TextStyle(color: AppColors.coralDeep),
        border: OutlineInputBorder(borderRadius: radius),
        enabledBorder: OutlineInputBorder(
          borderRadius: radius,
          borderSide: const BorderSide(color: AppColors.blush, width: 1.5),
        ),
        focusedBorder: OutlineInputBorder(
          borderRadius: radius,
          borderSide: const BorderSide(color: AppColors.coral, width: 2),
        ),
      ),
      filledButtonTheme: FilledButtonThemeData(
        style: FilledButton.styleFrom(
          minimumSize: const Size.fromHeight(52),
          shape: RoundedRectangleBorder(borderRadius: radius),
          textStyle: const TextStyle(fontSize: 16, fontWeight: FontWeight.w600),
        ),
      ),
      navigationBarTheme: const NavigationBarThemeData(
        backgroundColor: Colors.white,
        indicatorColor: AppColors.blush,
      ),
      snackBarTheme: const SnackBarThemeData(
        behavior: SnackBarBehavior.floating,
      ),
    );
  }
}
