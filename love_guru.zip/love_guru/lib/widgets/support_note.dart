import 'package:flutter/material.dart';

import '../app.dart';

/// Gentle disclaimer that Love Guru is not therapy or emergency help.
class SupportNote extends StatelessWidget {
  const SupportNote({super.key});

  static const String text =
      'Love Guru offers general relationship support and is not a replacement '
      'for professional therapy or emergency help.';

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: AppColors.blush,
        borderRadius: BorderRadius.circular(16),
      ),
      child: Row(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const Icon(Icons.info_outline, color: AppColors.coralDeep),
          const SizedBox(width: 12),
          Expanded(
            child: Text(
              text,
              style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                    color: AppColors.ink,
                    height: 1.4,
                  ),
            ),
          ),
        ],
      ),
    );
  }
}
