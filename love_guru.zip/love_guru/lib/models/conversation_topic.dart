import 'package:flutter/material.dart';

/// A guided conversation topic shown on the Connect tab.
class ConversationTopic {
  const ConversationTopic({
    required this.title,
    required this.description,
    required this.starterQuestion,
    required this.icon,
  });

  final String title;
  final String description;
  final String starterQuestion;
  final IconData icon;
}
