/// The couple's basic profile, stored locally on the device.
class UserProfile {
  const UserProfile({
    required this.yourName,
    required this.partnerName,
    required this.relationshipLength,
    required this.mainGoal,
  });

  static const List<String> relationshipLengths = [
    'Less than 1 year',
    '1–3 years',
    '3–5 years',
    '5+ years',
  ];

  static const List<String> goals = [
    'Communication',
    'Intimacy',
    'Conflict Repair',
    'Fun & Connection',
  ];

  final String yourName;
  final String partnerName;
  final String relationshipLength;
  final String mainGoal;

  factory UserProfile.empty() => UserProfile(
        yourName: '',
        partnerName: '',
        relationshipLength: relationshipLengths.first,
        mainGoal: goals.first,
      );

  Map<String, dynamic> toJson() => {
        'yourName': yourName,
        'partnerName': partnerName,
        'relationshipLength': relationshipLength,
        'mainGoal': mainGoal,
      };

  factory UserProfile.fromJson(Map<String, dynamic> json) {
    final length = json['relationshipLength'] as String?;
    final goal = json['mainGoal'] as String?;
    return UserProfile(
      yourName: json['yourName'] as String? ?? '',
      partnerName: json['partnerName'] as String? ?? '',
      relationshipLength: relationshipLengths.contains(length)
          ? length!
          : relationshipLengths.first,
      mainGoal: goals.contains(goal) ? goal! : goals.first,
    );
  }
}
