import 'package:flutter/material.dart';

import '../app.dart';
import '../services/demo_data.dart';
import '../widgets/app_card.dart';
import '../widgets/labeled_text_field.dart';
import '../widgets/section_header.dart';
import '../widgets/snack.dart';
import '../widgets/support_note.dart';

class RepairTab extends StatefulWidget {
  const RepairTab({super.key});

  @override
  State<RepairTab> createState() => _RepairTabState();
}

class _RepairTabState extends State<RepairTab> {
  final TextEditingController _whatHappened = TextEditingController();
  final TextEditingController _howYouFelt = TextEditingController();
  final TextEditingController _whatYouNeed = TextEditingController();

  String? _repairMessage;

  @override
  void dispose() {
    _whatHappened.dispose();
    _howYouFelt.dispose();
    _whatYouNeed.dispose();
    super.dispose();
  }

  void _createMessage() {
    FocusScope.of(context).unfocus();
    final allEmpty = [_whatHappened, _howYouFelt, _whatYouNeed]
        .every((c) => c.text.trim().isEmpty);
    if (allEmpty) {
      showAppSnackBar(context, 'Share a little about what happened first.');
      return;
    }
    // Demo only: a real AI response will replace this later.
    setState(() => _repairMessage = DemoData.repairMessage);
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SectionHeader(
          title: 'Let’s Repair Together',
          subtitle:
              'Share what happened. We’ll help you turn blame into understanding.',
        ),
        const SizedBox(height: 20),
        LabeledTextField(controller: _whatHappened, label: 'What happened?'),
        const SizedBox(height: 16),
        LabeledTextField(controller: _howYouFelt, label: 'How did you feel?'),
        const SizedBox(height: 16),
        LabeledTextField(
          controller: _whatYouNeed,
          label: 'What do you need right now?',
        ),
        const SizedBox(height: 20),
        FilledButton.icon(
          onPressed: _createMessage,
          icon: const Icon(Icons.favorite),
          label: const Text('Create Repair Message'),
        ),
        if (_repairMessage != null) ...[
          const SizedBox(height: 20),
          AppCard(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Row(
                  children: [
                    const Icon(Icons.chat_bubble_outline,
                        color: AppColors.coralDeep),
                    const SizedBox(width: 8),
                    Text(
                      'Your repair message',
                      style: textTheme.labelLarge?.copyWith(
                        color: AppColors.coralDeep,
                        fontWeight: FontWeight.w700,
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 12),
                SelectableText(
                  _repairMessage!,
                  style: textTheme.titleMedium?.copyWith(
                    color: AppColors.ink,
                    height: 1.45,
                  ),
                ),
              ],
            ),
          ),
        ],
        const SizedBox(height: 20),
        const SupportNote(),
      ],
    );
  }
}
