import 'package:flutter/material.dart';

import '../services/demo_data.dart';
import '../widgets/section_header.dart';
import '../widgets/topic_card.dart';
import 'conversation_detail_screen.dart';

class ConnectTab extends StatelessWidget {
  const ConnectTab({super.key});

  @override
  Widget build(BuildContext context) {
    const topics = DemoData.topics;
    return ListView.separated(
      padding: const EdgeInsets.all(20),
      itemCount: topics.length + 1,
      separatorBuilder: (_, index) =>
          SizedBox(height: index == 0 ? 20 : 12),
      itemBuilder: (context, index) {
        if (index == 0) {
          return const SectionHeader(
            title: 'Guided Conversations',
            subtitle: 'Pick a topic and take turns sharing. Go at your own pace.',
          );
        }
        final topic = topics[index - 1];
        return TopicCard(
          topic: topic,
          onTap: () => Navigator.of(context).push(
            MaterialPageRoute<void>(
              builder: (_) => ConversationDetailScreen(topic: topic),
            ),
          ),
        );
      },
    );
  }
}
