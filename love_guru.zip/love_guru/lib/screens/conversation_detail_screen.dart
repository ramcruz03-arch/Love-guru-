import 'package:flutter/material.dart';

import '../app.dart';
import '../models/conversation_topic.dart';
import '../widgets/app_card.dart';
import '../widgets/labeled_text_field.dart';
import '../widgets/snack.dart';

class ConversationDetailScreen extends StatefulWidget {
  const ConversationDetailScreen({super.key, required this.topic});

  final ConversationTopic topic;

  @override
  State<ConversationDetailScreen> createState() =>
      _ConversationDetailScreenState();
}

class _ConversationDetailScreenState extends State<ConversationDetailScreen> {
  final TextEditingController _myThoughts = TextEditingController();
  final TextEditingController _partnerThoughts = TextEditingController();

  @override
  void dispose() {
    _myThoughts.dispose();
    _partnerThoughts.dispose();
    super.dispose();
  }

  void _finish() {
    FocusScope.of(context).unfocus();
    if (_myThoughts.text.trim().isEmpty &&
        _partnerThoughts.text.trim().isEmpty) {
      showAppSnackBar(context, 'Share a few thoughts before finishing.');
      return;
    }
    // Demo only: nothing is stored yet.
    showAppSnackBar(
      context,
      'Conversation saved. Thank you for opening up to each other.',
    );
    Navigator.of(context).pop();
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    final topic = widget.topic;

    return Scaffold(
      appBar: AppBar(title: Text(topic.title)),
      body: SafeArea(
        child: ListView(
          padding: const EdgeInsets.fromLTRB(20, 8, 20, 24),
          children: [
            AppCard(
              color: AppColors.blush,
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Icon(topic.icon, color: AppColors.coralDeep),
                      const SizedBox(width: 8),
                      Text(
                        'Starter question',
                        style: textTheme.labelLarge?.copyWith(
                          color: AppColors.coralDeep,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(
                    topic.starterQuestion,
                    style: textTheme.titleLarge?.copyWith(
                      color: AppColors.ink,
                      height: 1.35,
                    ),
                  ),
                ],
              ),
            ),
            const SizedBox(height: 20),
            LabeledTextField(controller: _myThoughts, label: 'My thoughts'),
            const SizedBox(height: 16),
            LabeledTextField(
              controller: _partnerThoughts,
              label: 'My partner’s thoughts',
            ),
            const SizedBox(height: 24),
            FilledButton.icon(
              onPressed: _finish,
              icon: const Icon(Icons.check_circle_outline),
              label: const Text('Finish Conversation'),
            ),
          ],
        ),
      ),
    );
  }
}
