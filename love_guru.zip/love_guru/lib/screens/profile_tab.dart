import 'package:flutter/material.dart';

import '../models/user_profile.dart';
import '../services/storage_service.dart';
import '../widgets/section_header.dart';
import '../widgets/snack.dart';

class ProfileTab extends StatefulWidget {
  const ProfileTab({super.key});

  @override
  State<ProfileTab> createState() => _ProfileTabState();
}

class _ProfileTabState extends State<ProfileTab> {
  final StorageService _storage = const StorageService();
  final TextEditingController _yourName = TextEditingController();
  final TextEditingController _partnerName = TextEditingController();

  String _relationshipLength = UserProfile.relationshipLengths.first;
  String _mainGoal = UserProfile.goals.first;
  bool _loading = true;

  @override
  void initState() {
    super.initState();
    _loadProfile();
  }

  Future<void> _loadProfile() async {
    final profile = await _storage.loadProfile();
    if (!mounted) return;
    setState(() {
      _yourName.text = profile.yourName;
      _partnerName.text = profile.partnerName;
      _relationshipLength = profile.relationshipLength;
      _mainGoal = profile.mainGoal;
      _loading = false;
    });
  }

  Future<void> _saveProfile() async {
    FocusScope.of(context).unfocus();
    await _storage.saveProfile(
      UserProfile(
        yourName: _yourName.text.trim(),
        partnerName: _partnerName.text.trim(),
        relationshipLength: _relationshipLength,
        mainGoal: _mainGoal,
      ),
    );
    if (!mounted) return;
    showAppSnackBar(context, 'Profile saved.');
  }

  @override
  void dispose() {
    _yourName.dispose();
    _partnerName.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    if (_loading) {
      return const Center(child: CircularProgressIndicator());
    }

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SectionHeader(
          title: 'Your Profile',
          subtitle: 'A few details help Love Guru support you both.',
        ),
        const SizedBox(height: 20),
        TextField(
          controller: _yourName,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Your name',
            prefixIcon: Icon(Icons.person_outline),
          ),
        ),
        const SizedBox(height: 16),
        TextField(
          controller: _partnerName,
          textCapitalization: TextCapitalization.words,
          decoration: const InputDecoration(
            labelText: 'Partner’s name',
            prefixIcon: Icon(Icons.favorite_border),
          ),
        ),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          initialValue: _relationshipLength,
          decoration: const InputDecoration(
            labelText: 'Relationship length',
            prefixIcon: Icon(Icons.calendar_month_outlined),
          ),
          items: [
            for (final option in UserProfile.relationshipLengths)
              DropdownMenuItem(value: option, child: Text(option)),
          ],
          onChanged: (value) {
            if (value != null) setState(() => _relationshipLength = value);
          },
        ),
        const SizedBox(height: 16),
        DropdownButtonFormField<String>(
          initialValue: _mainGoal,
          decoration: const InputDecoration(
            labelText: 'Main goal',
            prefixIcon: Icon(Icons.people_alt_outlined),
          ),
          items: [
            for (final option in UserProfile.goals)
              DropdownMenuItem(value: option, child: Text(option)),
          ],
          onChanged: (value) {
            if (value != null) setState(() => _mainGoal = value);
          },
        ),
        const SizedBox(height: 24),
        FilledButton(
          onPressed: _saveProfile,
          child: const Text('Save Profile'),
        ),
      ],
    );
  }
}
