import 'package:flutter/material.dart';

import '../app.dart';
import '../services/demo_data.dart';
import '../widgets/app_card.dart';
import '../widgets/labeled_text_field.dart';
import '../widgets/section_header.dart';
import '../widgets/snack.dart';

class HomeTab extends StatefulWidget {
  const HomeTab({super.key});

  @override
  State<HomeTab> createState() => _HomeTabState();
}

class _HomeTabState extends State<HomeTab> {
  final TextEditingController _answerController = TextEditingController();

  @override
  void dispose() {
    _answerController.dispose();
    super.dispose();
  }

  void _submit() {
    FocusScope.of(context).unfocus();
    if (_answerController.text.trim().isEmpty) {
      showAppSnackBar(context, 'Write a few words first - there’s no wrong answer.');
      return;
    }
    showAppSnackBar(context, 'Your answer has been saved.');
  }

  @override
  Widget build(BuildContext context) {
    final textTheme = Theme.of(context).textTheme;
    const streak = DemoData.connectionStreakDays;

    return ListView(
      padding: const EdgeInsets.all(20),
      children: [
        const SectionHeader(title: 'Grow closer, one conversation at a time.'),
        const SizedBox(height: 20),
        AppCard(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Row(
                children: [
                  const Icon(Icons.favorite, color: AppColors.coral),
                  const SizedBox(width: 8),
                  Text(
                    'Daily Question',
                    style: textTheme.labelLarge?.copyWith(
                      color: AppColors.coralDeep,
                      fontWeight: FontWeight.w700,
                    ),
                  ),
                ],
              ),
              const SizedBox(height: 12),
              Text(
                DemoData.dailyQuestion,
                style: textTheme.titleLarge?.copyWith(
                  color: AppColors.ink,
                  height: 1.35,
                ),
              ),
              const SizedBox(height: 20),
              LabeledTextField(
                controller: _answerController,
                label: 'Your answer',
                minLines: 4,
              ),
              const SizedBox(height: 16),
              FilledButton(onPressed: _submit, child: const Text('Submit')),
            ],
          ),
        ),
        const SizedBox(height: 16),
        const AppCard(
          color: AppColors.blush,
          padding: EdgeInsets.symmetric(horizontal: 16, vertical: 14),
          child: Row(
            children: [
              Icon(Icons.local_fire_department, color: AppColors.coralDeep),
              SizedBox(width: 10),
              Text(
                'Connection Streak: $streak day',
                style: TextStyle(
                  fontSize: 16,
                  fontWeight: FontWeight.w600,
                  color: AppColors.ink,
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }
}
