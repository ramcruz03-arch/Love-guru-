# Love Guru

**Build deeper love, together.**

Love Guru is a beginner-friendly Flutter MVP for an AI relationship-support app for lovers and couples. It offers daily prompts, guided conversations, and gentle conflict-repair support. This version uses only local demo data: there is no login, no Firebase, and no real AI API yet.

## Features

- **Splash screen** with the Love Guru heart, title and tagline; moves on automatically after 2 seconds.
- **Onboarding** with a warm gradient and a "Get Started" button. Completion is saved locally with SharedPreferences, so returning users go straight to the app.
- **Home**: a daily question, an answer box with Submit, and a connection streak card.
- **Connect**: four guided conversation topics (Appreciation, Future Plans, Boundaries, Intimacy). Each opens a detail screen with a starter question and space for both partners' thoughts.
- **Repair**: share what happened, how you felt and what you need, then create a calm demo repair message. Includes a clear note that the app is not a replacement for professional therapy or emergency help.
- **Profile**: your name, partner's name, relationship length and main goal, saved locally on the device.
- Material 3, soft coral (#E97451) on warm off-white (#FFF7F3), 16px rounded cards.

## Project structure

```
lib/
  main.dart          App entry point
  app.dart           MaterialApp, theme and brand colours
  screens/           Splash, onboarding, main screen, 4 tabs, conversation detail
  widgets/           Reusable cards, text fields, headers, support note
  models/            ConversationTopic, UserProfile
  services/          Local storage (SharedPreferences) and demo data
test/                Widget tests
scripts/             setup_android.sh (generates android/ files)
```

## Requirements

- Flutter SDK (stable channel, Dart 3.9 or newer)
- An Android device (USB debugging on) or an Android emulator
- Android SDK / Android Studio for building

## First-time setup

This project was written without the `android/` platform folder so that it is generated to match *your* Flutter version. Run this once in the project folder:

**macOS / Linux / Git Bash:**

```bash
bash scripts/setup_android.sh
```

**Windows (PowerShell):**

```powershell
flutter create . --platforms android --org com.loveguru --project-name love_guru
```

On Windows, then open `android/app/src/main/AndroidManifest.xml` and change `android:label="love_guru"` to `android:label="Love Guru"`.

Existing files such as `lib/`, `pubspec.yaml` and `README.md` are not overwritten.

## Commands

```bash
flutter pub get
flutter run
flutter build apk --release
```

The release APK is produced at:

```
build/app/outputs/flutter-apk/app-release.apk
```

The release build is signed with the debug key by default, which is fine for testing. Set up your own signing key before publishing to the Play Store.

## Continuous integration

`.github/workflows/build_apk.yml` runs on every push to `main`: it sets up Java and stable Flutter, generates Android files if needed, runs `flutter pub get` and `flutter analyze`, builds the release APK, and uploads it as the artifact **love-guru-release-apk** (find it under the workflow run in the GitHub **Actions** tab).

## A note on care

Love Guru offers general relationship support and is not a replacement for professional therapy or emergency help.
